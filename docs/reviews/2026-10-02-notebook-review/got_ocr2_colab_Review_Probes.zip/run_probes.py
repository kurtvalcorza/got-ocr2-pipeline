"""Review probes for tutorials/got_ocr2_colab.ipynb (row 30, review only, CPU, no model).

Run from anywhere:  python run_probes.py <repo_worktree> <workdir>
P0 static checks; P1 carried-cell namespace collisions; P2 default data path (cell 13, real Hub fetch, ~44 MB);
P3 BYOD branch of cell 13 through a shimmed google.colab upload; P4 metric sanity; P5 generator --check and the
release-asset validator; P6 adapt() rerun semantics (source); P7 the archived Kaggle T4 run of the reviewed blob
(numbers the prose relies on). Optional third argument: the archived evidence directory.
No model weights are downloaded; Sections 3 and 5-9 are not executed.
"""
from __future__ import annotations

import ast
import hashlib
import io
import json
import os
import re
import sys
import time
import types
import zipfile
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
WORK = Path(sys.argv[2]).resolve()
NB_PATH = REPO / "tutorials" / "got_ocr2_colab.ipynb"
NB = json.loads(NB_PATH.read_text(encoding="utf-8"))
CELLS = NB["cells"]
SRC = ["".join(c["source"]) for c in CELLS]
RESULTS: dict = {}


def src(i: int) -> str:
    return SRC[i]


# ---------------------------------------------------------------- P0 static
md = "\n".join(SRC[i] for i, c in enumerate(CELLS) if c["cell_type"] == "markdown")
markers = {k: bool(re.search(p, md, re.I)) for k, p in {
    "how_to_use": r"how to use this notebook", "roadmap": r"roadmap", "glossary": r"glossary",
    "check_your_reasoning": r"check your reasoning", "what_to_notice": r"what to notice",
    "conclusion_template": r"conclusion (template|scaffold)", "infrastructure_label": r"infrastructure",
    "intended_learner": r"intended (learner|audience)|this notebook is for", "predict_prompt": r"\bpredict\b(?! )|make a prediction|before you run",
    "troubleshooting": r"troubleshooting", "look_for": r"look for|watch the|expect",
    "run_to_run_variability": r"not bit|bit-reproduc|varies|will vary|run-to-run|nondetermin|non-determin",
}.items()}
code_cells = [i for i, c in enumerate(CELLS) if c["cell_type"] == "code"]
RESULTS["P0_static"] = {
    "nbformat": [NB["nbformat"], NB["nbformat_minor"]],
    "metadata_dimer": NB["metadata"].get("dimer"),
    "n_cells": len(CELLS), "code_cells": code_cells,
    "carried_cell_lines": {i: SRC[i].count("\n") + 1 for i in (5, 7, 9)},
    "persisted_outputs": sum(len(CELLS[i].get("outputs", [])) for i in code_cells),
    "cellView_form_cells": [i for i in code_cells if CELLS[i].get("metadata", {}).get("cellView") == "form"],
    "pip_install_in_kernel": "pip', 'install'" in src(3),
    "restart_instruction_in_install_cell": "Restart the runtime" in src(3),
    "uses_uv": "uv venv" in "\n".join(SRC) or "uv pip" in "\n".join(SRC),
    "env_var_skip_install": "DIMER_NOTEBOOK_CI_PREINSTALLED" in src(3),
    "env_var_documented_in_markdown": "DIMER_NOTEBOOK_CI_PREINSTALLED" in md,
    "guided_markers": markers,
    "byod_location_field": bool(re.search(r"BYOD_(PATH|ZIP|DIR)\s*=", src(13))),
    "byod_uses_files_upload": "files.upload()" in src(13),
    "cell21_hard_asserts": re.findall(r"^assert .*$", src(21), re.M),
    "cell20_eighty_lines": "Eighty lines" in src(20),
    "cell18_loss_claim": re.findall(r"loss drops from about [0-9.]+ to [0-9.]+", src(18)),
    "cell18_val_claim": re.findall(r"validation CER fall from [0-9.]+ to [0-9.]+ \(epoch \d[^)]*\)", src(18)),
    "cell0_question_cer_and_wer_past_baselines": "**CER** and **WER** on a line-disjoint test split past two **non-adapted baselines**" in src(0),
    "cell21_beats_both_flag_uses_only_cer": "'adapted_beats_both_baselines': adapted_test['cer'] < min(baseline_empty['cer'], baseline_constant['cer'])" in src(21),
    "cell0_byod_rerun_instruction": "re-run from that cell" in src(0),
    "cell0_restart_in_timing": "with the pinned install and its restart" in src(0),
    "cell1_runtime_python": re.findall(r"Python 3\.\d+", src(1)),
    "cell24_format_mode_needs_code_edit": "mode='format'" in src(24) and "MODE" not in src(15).split("def printed_page")[0],
    "experiments_name_rerun_scope": bool(re.search(r"re-?run (from|cells?) ", src(24), re.I)),
    "cell0_byod_min_images_claim": re.findall(r"at least (\w+) images", src(0)),
    "cell13_has_path_import": "from pathlib import Path" in src(13),
    "cell1_dataset_bounds_claim": re.findall(r"a dataset needs ([0-9.,]+) records", src(1)),
    "cell24_split_page_advice": "lines cut from the same page share a hand" in src(24),
    "cell0_without_leakage_claim": "split it by line without leakage" in src(0),
    "spec_declared": NB["metadata"]["dimer"].get("notebook_spec"),
    "every_code_cell_compiles": {},
}
for i in code_cells:
    try:
        compile(SRC[i], f"cell{i}", "exec")
        RESULTS["P0_static"]["every_code_cell_compiles"][i] = True
    except SyntaxError as exc:
        RESULTS["P0_static"]["every_code_cell_compiles"][i] = repr(exc)

# ---------------------------------------------------------------- P1 carried-cell namespace collisions
def top_level_assigned(code: str) -> dict:
    out = {}
    for node in ast.parse(code).body:
        targets = []
        if isinstance(node, ast.Assign):
            targets = [t.id for t in node.targets if isinstance(t, ast.Name)]
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            targets = [node.target.id]
        elif isinstance(node, (ast.FunctionDef, ast.ClassDef)):
            targets = [node.name]
        for t in targets:
            out[t] = ast.unparse(node)[:160]
    return out


defs = {i: top_level_assigned(SRC[i]) for i in (5, 7, 9)}
collisions = {}
for a in (5, 7, 9):
    for b in (5, 7, 9):
        if a < b:
            for name in set(defs[a]) & set(defs[b]):
                collisions[name] = {f"cell{a}": defs[a][name], f"cell{b}": defs[b][name]}
os.chdir(WORK)
ns: dict = {"__name__": "__main__"}
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
for i in (3, 5, 7, 9):
    exec(compile(SRC[i], f"cell{i}", "exec"), ns)
sys.path.insert(0, str(REPO / "src"))
import got_ocr2_pipeline.pipeline as pkg_pipeline
import got_ocr2_pipeline.samples as pkg_samples  # noqa: E402
from PIL import Image  # noqa: E402

def mod_consts(mod):
    return {k: getattr(mod, k) for k in dir(mod) if k.isupper() and isinstance(getattr(mod, k), (int, float, str))}
pkg_consts = {**mod_consts(pkg_samples), **mod_consts(pkg_pipeline)}
ns_mismatch = {}
for mod in (pkg_pipeline, pkg_samples):
    for k, v in mod_consts(mod).items():
        if k in ns and ns[k] != v:
            ns_mismatch[f"{mod.__name__}.{k}"] = {"package": v, "notebook": ns[k]}
RESULTS["P1_namespace"] = {
    "colliding_top_level_names": collisions,
    "constants_differing_between_package_module_and_notebook_namespace": ns_mismatch,
}
json.dump(RESULTS, open(WORK / "results.partial.json", "w"), indent=1, default=str)

# ---------------------------------------------------------------- P4 metric sanity
recs = [{"id": "a", "text": "abc def"}, {"id": "b", "text": "xy"}]
RESULTS["P4_metrics"] = {
    "empty": {k: ns["ocr_metrics"](["", ""], recs)[k] for k in ("cer", "wer", "exact_match")},
    "overgeneration_cer": ns["ocr_metrics"](["abc def ghijkl mnop", "xy xy xy"], recs)["cer"],
    "perfect": ns["ocr_metrics"](["abc  def", "xy"], recs)["cer"],
}

# ---------------------------------------------------------------- P2 default data path (cell 13)
def run_cell13(use_byod: bool, upload=None, seed=42):
    code = SRC[13].replace("USE_BYOD = False  # @param", f"USE_BYOD = {use_byod}  # @param").replace("SPLIT_SEED = 42  # @param", f"SPLIT_SEED = {seed}  # @param")
    if upload is not None:
        colab = types.ModuleType("google.colab")
        colab.files = types.SimpleNamespace(upload=upload)
        google = types.ModuleType("google")
        google.colab = colab
        sys.modules["google"] = google
        sys.modules["google.colab"] = colab
    out = io.StringIO()
    old = sys.stdout
    sys.stdout = out
    try:
        exec(compile(code, "cell13", "exec"), ns)
        err = None
    except Exception as exc:  # noqa: BLE001
        err = f"{type(exc).__name__}: {exc}"
    finally:
        sys.stdout = old
    return {"error": err, "stdout": out.getvalue()[-3000:]}

t0 = time.perf_counter()
p2 = run_cell13(False)
p2["seconds"] = round(time.perf_counter() - t0, 1)
if p2["error"] is None:
    tr, va, te = ns["train_records"], ns["val_records"], ns["test_records"]
    idnum = lambda r: int(r["id"].rsplit("-", 1)[1])  # noqa: E731
    train_ids = {idnum(r) for r in tr}
    train_texts = {r["text"] for r in tr}
    adj = sum(1 for r in te if (idnum(r) - 1) in train_ids or (idnum(r) + 1) in train_ids)
    rg = {}
    for r in te:
        rg[r["source_row_group"]] = rg.get(r["source_row_group"], 0) + 1
    p2["leakage_proxy"] = {
        "test_lines": len(te),
        "test_lines_with_an_adjacent_corpus_line_in_train": adj,
        "test_row_groups": rg,
        "test_texts_exactly_in_train": sum(1 for r in te if r["text"] in train_texts),
        "test_texts_exactly_in_train_examples": sorted({r["text"] for r in te if r["text"] in train_texts})[:10],
        "val_texts_exactly_in_train": sum(1 for r in va if r["text"] in train_texts),
    }
    p2["outputs"] = sorted(os.listdir("outputs"))
    p2["digests"] = {k: v["digest"] for k, v in ns["dataset_manifests"].items()}
    p2["sample_digest_pin"] = ns["SAMPLE_DIGEST"]
    p2["combined_digest"] = ns["dataset_digest"](tr + va + te)
RESULTS["P2_default_data_path"] = p2
json.dump(RESULTS, open(WORK / "results.partial.json", "w"), indent=1, default=str)

# ---------------------------------------------------------------- P3 BYOD branch of cell 13
from PIL import ImageDraw  # noqa: E402

def line_png(i: int, w: int = 300) -> bytes:
    im = Image.new("RGB", (w, 40), (255, 255, 255))
    ImageDraw.Draw(im).text((5, 10), f"line {i}", fill=(0, 0, 0))
    buf = io.BytesIO()
    im.save(buf, "PNG")
    return buf.getvalue()

def make_zip(members: dict) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for name, data in members.items():
            z.writestr(name, data)
    return buf.getvalue()

def csv_of(rows):
    return ("file,text\n" + "".join(f"{f},{t}\n" for f, t in rows)).encode()

def simple(n):
    m = {f"l{i}.png": line_png(i) for i in range(n)}
    m["transcripts.csv"] = csv_of([(f"l{i}.png", f"line {i}") for i in range(n)])
    return m

cases = {}
for n in (8, 20, 38, 49, 50):
    payload = make_zip(simple(n))
    cases[f"n={n}"] = run_cell13(True, upload=lambda p=payload: {"lines.zip": p})
    if cases[f"n={n}"]["error"] is None:
        cases[f"n={n}"]["splits"] = ns["disjoint"]
# same basename in two folders -> flattened
m = {"a/x.png": line_png(1), "b/x.png": line_png(2, 500)}
m.update({f"l{i}.png": line_png(i + 10) for i in range(60)})
m["transcripts.csv"] = csv_of([("a/x.png", "first"), ("b/x.png", "second")] + [(f"l{i}.png", f"line {i}") for i in range(60)])
cases["same_basename_two_folders"] = run_cell13(True, upload=lambda p=make_zip(m): {"dup.zip": p})
if cases["same_basename_two_folders"]["error"] is None:
    cases["same_basename_two_folders"]["splits"] = ns["disjoint"]
# duplicate images (same pixels, different files) -> silently dropped?
m = simple(60)
for i in range(10):
    m[f"dup{i}.png"] = line_png(i)
m["transcripts.csv"] = csv_of([(f"l{i}.png", f"line {i}") for i in range(60)] + [(f"dup{i}.png", f"line {i}") for i in range(10)])
r = run_cell13(True, upload=lambda p=make_zip(m): {"dups.zip": p})
if r["error"] is None:
    r["records_in"] = 70
    r["splits"] = ns["disjoint"]
    r["stdout_mentions_dropped"] = bool(re.search(r"drop|duplicate|de-dup", r["stdout"], re.I))
    r["stdout_mentions_dropped_note"] = "regex also matches cell 13's own 'duplicate id' refusal probe; the split (39+9+12=60 of 70) is the evidence that 10 were dropped without a message"
cases["10_duplicate_images_of_70"] = r
m = simple(60); m["notes.txt"] = b"hello"; m["transcripts.csv"] = csv_of([(f"l{i}.png", f"line {i}") for i in range(60)] + [("notes.txt", "x")])
cases["non_image_member"] = run_cell13(True, upload=lambda p=make_zip(m): {"bad.zip": p})
m = simple(60); del m["transcripts.csv"]
cases["missing_transcripts_csv"] = run_cell13(True, upload=lambda p=make_zip(m): {"nocsv.zip": p})
m = simple(60); m["transcripts.csv"] = csv_of([(f"l{i}.png", ("y" * 513) if i == 3 else f"line {i}") for i in range(60)])
cases["text_513_chars"] = run_cell13(True, upload=lambda p=make_zip(m): {"long.zip": p})
cases["not_a_zip"] = run_cell13(True, upload=lambda: {"lines.tar": b"not a zip"})
cases["cancelled_upload"] = run_cell13(True, upload=lambda: {})
for v in cases.values():
    v["stdout"] = v["stdout"][-600:]
RESULTS["P3_byod_cell13"] = cases

# ---------------------------------------------------------------- P5 generator parity and validator
import subprocess  # noqa: E402
def run(cmd):
    p = subprocess.run(cmd, cwd=REPO, capture_output=True, text=True, timeout=600)
    return {"cmd": " ".join(cmd[1:]), "exit": p.returncode, "tail": (p.stdout + p.stderr)[-800:]}
RESULTS["P5_generator"] = [run([sys.executable, "tools/build_notebook.py", "--check"]), run([sys.executable, "tools/validate_release_assets.py"])]

# ---------------------------------------------------------------- P6 adapt() rerun semantics (source)
psrc = (REPO / "src" / "got_ocr2_pipeline" / "pipeline.py").read_text(encoding="utf-8")
adapt_src = psrc[psrc.index("    def adapt("):psrc.index("    def save_artifact(")]
RESULTS["P6_adapt_rerun"] = {
    "restore_point_is_current_weights": "frozen_state = {k: v.detach().clone() for k, v in model.state_dict().items() if k in name_set}" in adapt_src,
    "epoch0_labelled_frozen_model": '"note": "frozen model"' in adapt_src,
    "refuses_when_already_adapted": bool(re.search(r"if self\.adapter[^\n]*:\s*\n\s*raise", adapt_src)),
    "section6_frozen_eval_uses_shared_pipe": "frozen_test = pipe.evaluate(" in src(17),
    "section5_frozen_page_uses_shared_pipe": "recognise_page(pipe, 'frozen')" in src(15),
    "model_loaded_only_in_cell11": [i for i in code_cells if "GotOcr2Pipeline.from_pretrained(" in SRC[i]],
}

# ---------------------------------------------------------------- P7 archived Kaggle T4 evidence of the reviewed blob
if len(sys.argv) > 3:
    ev = Path(sys.argv[3])
    rs = json.loads((ev / "run_summary.json").read_text(encoding="utf-8"))
    rep = json.loads((ev / "outputs" / "got_ocr2_evaluation_report.json").read_text(encoding="utf-8"))
    cmp_ = rep["comparison"]
    hist = [{"epoch": h["epoch"], "train_loss": h["train_loss"], "val_cer": (h.get("val") or {}).get("cer")} for h in rep["history"]]
    RESULTS["P7_kaggle_evidence"] = {
        "blob": rs["identity"].get("committed_blob"), "fetched_blob_verified": rs["identity"].get("fetched_blob_verified"),
        "pass1": {k: (v[:300] if isinstance(v, str) else v) for k, v in rs["runner"]["passes"][0].items()},
        "n_passes": len(rs["runner"]["passes"]),
        "comparison": cmp_,
        "adapted_wer_vs_empty": [cmp_["wer"]["adapted"], cmp_["wer"]["empty"]],
        "adapted_wer_vs_constant": [cmp_["wer"]["adapted"], cmp_["wer"]["constant"]],
        "adapted_wer_beats_empty": cmp_["wer"]["adapted"] < cmp_["wer"]["empty"],
        "adapted_wer_beats_constant": cmp_["wer"]["adapted"] < cmp_["wer"]["constant"],
        "history": hist,
        "test_n": rep["splits"],
        "pass1_restart_message": (re.findall(r"Core dependencies changed while older modules were loaded: [a-z].*?rerun from the top\.", (ev / "run_summary.json").read_text(encoding="utf-8")) or [None])[0],
        "restarted_after_install_cell": '"restarted_after_install_cell": true' in (ev / "run_summary.json").read_text(encoding="utf-8"),
    }

json.dump(RESULTS, open(WORK / "results.json", "w", encoding="utf-8"), indent=1, default=str, ensure_ascii=False)
print("done")
